from RoDevGameEngine import script
from RoDevGameEngine import input
from RoDevGameEngine import gameObjects

class PrintSpam(script.script):
    def __init__(self, parent : gameObjects.gameObject3D):
        super().__init__(parent)   
        self.parent = parent 
        
    def update(self, deltatime):
        super().update(deltatime)
    
        print("printspammer haha funny lol")