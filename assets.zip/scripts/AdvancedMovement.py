from RoDevGameEngine import script
from RoDevGameEngine import input
from RoDevGameEngine import gameObjects

class BasicMovement(script.script):
    def __init__(self, parent : gameObjects.gameObject3D):
        super().__init__(parent)   
        self.parent = parent 
        self.parent_transform = self.parent.get_transform()

        self.speed = 4

    def update(self, deltatime):
        super().update(deltatime)

        vel = [0, 0, 0]

        if input.get_key_down(input.keyCodes.KEY_L):
            vel[0] += self.speed*deltatime
        elif input.get_key_down(input.keyCodes.KEY_J):
            vel[0]-= self.speed*deltatime
        if input.get_key_down(input.keyCodes.KEY_I):
            vel[2] += self.speed*deltatime
        elif input.get_key_down(input.keyCodes.KEY_K):
            vel[2] -= self.speed*deltatime
        if input.get_key_down(input.keyCodes.KEY_SPACE):
            vel[1] += self.speed*deltatime
        elif input.get_key_down(input.keyCodes.KEY_RIGHT_CONTROL):
            vel[1] -= self.speed*deltatime

        self.parent_transform.move(vel)

    def on_collision_enter(self, my_obb, other):
        super().on_collision_enter(my_obb, other)

        print("Test")
